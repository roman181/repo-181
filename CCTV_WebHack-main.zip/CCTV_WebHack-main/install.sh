cp webhack /data/data/com.termux/files/usr/bin/
cd /data/data/com.termux/files/usr/bin/
chmod +777 webhack
cd $Home
pip3 install requests
clear
