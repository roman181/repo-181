This program needs to hack IP cameras CCTV in the world.
For setup you need to write these commands in termux:


Done!
To start you need write command: `python3 webhack.py`

*Thanks for downloading and using this program I'm really happy :)*
