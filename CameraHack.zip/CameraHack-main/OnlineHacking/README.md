
## How Works ?

First of all This tool host a phishing site on attacker local network. This tool gives two port forwarding option (NGROK or SERVEO) to take website over the internet. Now come on the main Point, attacker simply open the tool by using terminal and generate a link, when Link is generated attacker send that link to the target. If target open the link, target ip will transfer to the attacker. After Website load, the website ask for Camera access and when target give the permission the website will take cam shots one by one and send it to the Attacker.

## Installation :
#### Link : https://www.onlinehacking.in/hack-front-camera-target-phone-using-termux-linux

## Features

* Two port forwarding option (NGROK or SERVEO)
* Live target image.
* Easy to use
* Gives anonymity
* It gives you Responsive Website.
* Auto Installation (Termux).

## The Tool is for :

* Kali Linux
* Termux
* MacOS
* Ubuntu
* Perrot Sec OS
* Garuda Linux

## Requirements :

* Better Internet Connection
* 300 Storage


## Language is used to Make this tool

* Bash Script
* HTML
* PHP
* JavaScript
* CSS

## Warning

**MadCam tool is only for Educational Purpose. If any user use MadCam Tool is For illegal purpose or taking revenge, In this case the owner will not Responsible. Use of MadCam tool is Complete Responsibility of the user. If any User misuse MadCam tool then the tool and its owner will not Responsible.**
